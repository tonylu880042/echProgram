---
name: Echelon Tactical Instrument
colors:
  surface: '#0f1419'
  surface-dim: '#0f1419'
  surface-bright: '#353a3f'
  surface-container-lowest: '#0a0f14'
  surface-container-low: '#171c21'
  surface-container: '#1b2025'
  surface-container-high: '#262a30'
  surface-container-highest: '#30353b'
  on-surface: '#dfe3ea'
  on-surface-variant: '#bec7d3'
  inverse-surface: '#dfe3ea'
  inverse-on-surface: '#2c3136'
  outline: '#89929d'
  outline-variant: '#3f4852'
  surface-tint: '#97cbff'
  primary: '#97cbff'
  on-primary: '#003354'
  primary-container: '#28a8ff'
  on-primary-container: '#003b5f'
  inverse-primary: '#00639c'
  secondary: '#a6caf0'
  on-secondary: '#063352'
  secondary-container: '#244969'
  on-secondary-container: '#95b9de'
  tertiary: '#ffb86e'
  on-tertiary: '#492900'
  tertiary-container: '#e88b00'
  on-tertiary-container: '#542f00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#cee5ff'
  primary-fixed-dim: '#97cbff'
  on-primary-fixed: '#001d33'
  on-primary-fixed-variant: '#004a77'
  secondary-fixed: '#cee5ff'
  secondary-fixed-dim: '#a6caf0'
  on-secondary-fixed: '#001d33'
  on-secondary-fixed-variant: '#244969'
  tertiary-fixed: '#ffdcbd'
  tertiary-fixed-dim: '#ffb86e'
  on-tertiary-fixed: '#2c1600'
  on-tertiary-fixed-variant: '#693c00'
  background: '#0f1419'
  on-background: '#dfe3ea'
  surface-variant: '#30353b'
typography:
  metric-xl:
    fontFamily: JetBrains Mono
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.02em
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.01em
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 32px
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  nav_rail_width: 64px
  touch_target_min: 48px
  grid_gutter: 12px
---

## Brand & Style

This design system is engineered for high-performance fitness telemetry. The aesthetic is a "Digital Cockpit"—a precise, high-density environment that prioritizes rapid data legibility and low-latency interaction. 

The style is **Modern/Corporate** with a **Tactical** lean, stripping away decorative elements like gradients, blurs, and glow in favor of flat, utilitarian surfaces. The interface is designed to feel like a professional instrument panel found in aviation or high-end racing vehicles, ensuring that the athlete’s focus remains on performance metrics.

## Colors

The palette is strictly functional, utilizing a deep "Canvas" base for maximum contrast and reduced eye strain in low-light workout environments. 

- **Primary Accent:** Used exclusively for interactive elements and critical state indicators.
- **Surface Hierarchy:** Carbon Low and Carbon High are used to create structural containment and z-axis separation without the need for shadows.
- **Typography Tiers:** High-contrast White-Blue for readability, Grey-Blue for labels, and Muted Blue for secondary metadata.
- **Lines:** 1dp rules are used to compartmentalize data without adding visual bulk.

## Typography

Typography is divided into two functional families:
1. **Hanken Grotesk:** A clean, sharp sans-serif used for all UI labels, navigation, and instructional text. Its contemporary geometric structure ensures clarity at various weights.
2. **JetBrains Mono:** Utilized for all numerical telemetry (Speed, Incline, Heart Rate, Time). The monospaced nature prevents "jumping" layouts as numbers change rapidly during a workout, ensuring tabular alignment across dashboard modules.

All telemetry headers should use `label-caps` for high-density information architecture.

## Layout & Spacing

The layout is optimized for a 16:9 landscape aspect ratio with a **Fixed Grid** system.

- **Navigation Rail:** A permanent 64dp vertical rail on the left or right side for primary mode switching.
- **Spacing Rhythm:** Based on a strict 4dp grid. All margins, paddings, and component heights must be multiples of 4.
- **Touch Safety:** While the density is high, every interactive element must maintain a minimum 48dp hit area to accommodate movement during high-intensity exercise.
- **Telemetry Modules:** Use a 12-column grid. Large metrics typically span 3-4 columns, while secondary data points span 2.

## Elevation & Depth

Depth is conveyed through **Tonal Layers** rather than shadows. 
- **Level 0 (Canvas):** The background (#071016).
- **Level 1 (Modules):** Surface Carbon Low (#0C171E) for card containers and grouping.
- **Level 2 (Interactions):** Surface Carbon High (#12232C) for button backgrounds and active input fields.

**1dp Rules** are used to define boundaries between adjacent data points within a single module. No drop shadows are permitted; all depth is achieved through hex value variance and stroke definition.

## Shapes

The design uses a **Soft** shape language to provide a slight ergonomic feel while maintaining the precision of the cockpit aesthetic.

- **Standard Radius:** 4px (0.25rem) for all buttons, modules, and input fields.
- **Interactive States:** Active items maintain the same 4px radius but are defined by a 1dp #28A8FF border or solid fill.
- **Icons:** Use linear, 2px stroke weight icons to match the thin-rule aesthetic of the layout.

## Components

- **Buttons:** Primary buttons use a solid #28A8FF fill with #071016 text. Secondary buttons use a 1dp #253842 stroke with #E5EDF2 text.
- **Telemetry Cards:** Background #0C171E. Header text uses `label-caps` in #A4B3BD. Main value uses `metric-lg` in #E5EDF2.
- **Navigation Rail Items:** 64dp x 64dp icons. Active state uses a 4dp vertical #28A8FF bar on the outer edge.
- **Progress Bars:** Background #253842, Fill #28A8FF. Height 4dp or 8dp.
- **Input Fields:** Stepper-style controls (Plus/Minus) are preferred over keyboards. Large buttons for quick adjustments to speed/incline, minimum 48dp size.
- **Lists:** Clean rows separated by 1dp #253842 rules. No chevrons; use active color states to indicate selection.
- **Status Chips:** Small 24dp height containers with #12232C background and #A4B3BD `body-sm` text for state indicators (e.g., "Bluetooth Connected").